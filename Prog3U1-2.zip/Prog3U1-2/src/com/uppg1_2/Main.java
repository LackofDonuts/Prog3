package com.uppg1_2;

/**
 * Created by Dannyy on 6.4.2017.
 */
public class Main {

    public static void main(String[] args) {

        //OBS, grafen har ibland en bugg som gör att man måste trycka Do Query pånytt för att visa grafen.

        Model model = new Model();
        View view = new View(model);
        Controller controller = new Controller(view, model);
    }
}
