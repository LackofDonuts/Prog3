package com.uppg1_2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.text.DecimalFormat;
import java.util.ArrayList;


/**
 * Created by Dannyy on 6.3.2017.
 */
public class View {

    private Model model;
    private JFrame frame;
    private JPanel pane, paneMain, graphArea, valueContainer1;
    private JButton queryButton;
    private JLabel tick1, tick2, startDate, endDate, exampleDate, currVal1, currVal2, currDate;
    JTextField textTick1, textTick2, startDateTick, endDateTick;
    private JRadioButton usd, eur, sek;
    private JTextArea infoArea;
    private ButtonGroup bg;
    GridBagConstraints c;
    JScrollPane scroll;
    StockGraph gt;

    View(Model model) {
        this.model = model;
        //Skapa fönstren dit allting läggs
        frame = new JFrame();
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        paneMain = new JPanel();
        frame.getContentPane().add(paneMain);
        pane = new JPanel(new GridBagLayout());
        paneMain.add(pane);
        frame.setSize(600, 1000);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        //frame.addMouseMotionListener(this);

        //Instantiera alla komponenter och sätt deras egenskaper
        queryButton = new JButton("Do query");
        currVal1 = new JLabel("Value1");
        currVal2 = new JLabel("Value2");
        currDate = new JLabel("Date");
        tick1 = new JLabel("Ticker 1 ");
        tick2 = new JLabel("Ticker 2 ");
        startDate = new JLabel("Startdatum ");
        endDate = new JLabel("Slutdatum ");
        exampleDate = new JLabel("I formatet dd.mm.yyyy");
        textTick1 = new JTextField(10);
        textTick2 = new JTextField(10);
        startDateTick = new JTextField(10);
        endDateTick = new JTextField(10);
        usd = new JRadioButton("USD");
        eur = new JRadioButton("EUR");
        sek = new JRadioButton("SEK");
        usd.setActionCommand("USD");
        eur.setActionCommand("EUR");
        sek.setActionCommand("SEK");
        bg = new ButtonGroup();
        bg.add(usd);
        bg.add(eur);
        bg.add(sek);
        usd.setSelected(true);
        infoArea = new JTextArea(20, 45);
        infoArea.setEditable(false);
        infoArea.setAutoscrolls(true);
        scroll = new JScrollPane(infoArea);
        graphArea = new JPanel();
        graphArea.setPreferredSize(new Dimension(480, 500));
        valueContainer1 = new JPanel();
        valueContainer1.setPreferredSize(new Dimension(220, 20));

        c = new GridBagConstraints();
        //Initial values för gridbag
        c.gridx = 0;
        c.gridy = 0;
        c.anchor = GridBagConstraints.LINE_END;
        c.ipady = 5;
        c.insets = new Insets(0, 115, 6, 3);


        //Labels
        pane.add(tick1, c);
        c.gridy++;
        pane.add(tick2, c);
        c.gridy++;
        pane.add(startDate, c);
        c.gridy++;
        pane.add(endDate, c);

        c.gridx = 1;
        c.gridy = 0;
        c.insets = new Insets(0, 0, 6, 0);

        //Inputfields
        pane.add(textTick1, c);
        c.gridy = 1;
        pane.add(textTick2, c);
        c.gridy = 2;
        startDateTick.setText("3.1.2017");
        pane.add(startDateTick, c);
        c.gridy = 3;
        endDateTick.setText("29.3.2017");
        pane.add(endDateTick, c);
        c.gridx = 2;
        c.anchor = GridBagConstraints.WEST;
        pane.add(exampleDate, c);
        //Knappen
        c.gridx = 1;
        c.gridy = 4;
        c.anchor = GridBagConstraints.CENTER;
        pane.add(queryButton, c);

        //Valuta radiobuttons
        c.insets = new Insets(0, 0, 0, 0);
        c.gridy = 0;
        c.gridx = 2;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.LINE_END;

        pane.add(usd, c);
        c.gridy = 1;
        pane.add(eur, c);
        c.gridy = 2;
        pane.add(sek, c);

        //Stora textfältet
        c.gridx = 0;
        c.gridy = 5;
        c.fill = GridBagConstraints.EAST;
        c.gridheight = 3;
        c.gridwidth = 3;
        c.insets = new Insets(5, 5, 5, 5);
        pane.add(scroll, c);

        //Initial mode av grafen
        c.gridx = 0;
        c.gridy = 8;
        c.fill = GridBagConstraints.BOTH;
        c.gridheight = 4;
        c.gridwidth = 4;
        c.insets = new Insets(2, 5, 1, 5);
        gt = new StockGraph();
        gt.setPreferredSize(new Dimension(400, 430));
        pane.add(gt, c);

        c.gridy = 13;
        c.gridx = 0;
        c.fill = GridBagConstraints.BOTH;
        c.anchor = GridBagConstraints.CENTER;
        c.gridheight = 0;
        c.gridwidth = 0;
        c.insets = new Insets(0, 0, 0, 0);
        valueContainer1.add(currDate);
        valueContainer1.add(currVal1);
        valueContainer1.add(currVal2);
        pane.add(valueContainer1, c);

        c.gridx = 0;
        c.gridy = 8;
        c.fill = GridBagConstraints.BOTH;
        c.gridheight = 4;
        c.gridwidth = 4;
        c.insets = new Insets(2, 5, 1, 5);


        //Visa allting
        frame.pack();
        frame.setVisible(true);
    }


    void addListener(ActionListener doQueryListener, MouseMotionListener mouseMotionListener) {
        queryButton.addActionListener(doQueryListener);
        frame.addMouseMotionListener(mouseMotionListener);
    }

    void displayErrorMessage(String errorMessage) {
        System.out.println(errorMessage);
    }

    public void setInfoArea(String s) {
        infoArea.setText(s);
    }

    public String getTicker1() {
        return textTick1.getText();
    }

    public String getTicker2() {
        return textTick2.getText();
    }

    public String getStartDate() {
        return startDateTick.getText();
    }

    public String getEndDate() {
        return endDateTick.getText();
    }

    public String getCurrency() {
        return bg.getSelection().getActionCommand();
    }


    public void setGraph(ArrayList<Double> d) {
        gt = new StockGraph(d);
        pane.add(gt, c);
        frame.pack();
    }

    public void setGraph(ArrayList<Double> d1, ArrayList<Double> d2) {
        gt = new StockGraph(d1, d2);
        pane.add(gt, c);
        frame.pack();
    }

    public void setMouseOver(int e) {
        gt.setX(e);
        gt.mouseover();
    }

    public void setMouseValue() {
        DecimalFormat df = new DecimalFormat(".##");
        currVal1.setText(getTicker1() + ": " + df.format(gt.getValue1()));
        currVal2.setText(getTicker2() + ": " + df.format(gt.getValue2()));
    }

    public int getPos() {
        return gt.getPos();
    }

    public void setDate(String date) {
        currDate.setText(date + " - ");
    }
}